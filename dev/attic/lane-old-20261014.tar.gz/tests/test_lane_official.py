"""`vision/lane_official.py` 单元测试：合成图 + 纯函数，不碰硬件、不需要摄像头。

覆盖要点（每条对应一次真实踩坑或一个红线）：
  1. 对称车道 → 中心≈目标点、误差≈0；车道整体平移 → 中心跟着平移（方向不能反）；
  2. 斜率先验：近水平 / 近竖直亮条不能冒充车道线（|k| 闸门）；
  3. 单侧兜底（参考实现原样：缺侧代画面边界）与 single_mode=off 的区别；
  4. 两侧都没线 → lost；ROI 罩不到线 → lost，ROI 罩到 → 双侧（"带子选哪"是调参核心）；
  5. demo 的 min_lines 判停口径；
  6. Canny 自适应要钳在合法区间内（不钳会跑飞）；
  7. 误差符号：中心在目标右边 → error > 0。

跑法：
    cd dev && PYTHONPATH=. python tests/test_lane_official.py
"""
from __future__ import annotations

import sys

import cv2
import numpy as np

from vision.lane_official import (CANNY_HIGH_MAX, CANNY_HIGH_MIN, CANNY_LOW_MAX,
                                  CANNY_LOW_MIN, PROFILES, LaneDetector, LaneParams,
                                  LaneResult, summarize)

W, H = 640, 480


def _lane_image(van_x: float = 320.0, left: bool = True, right: bool = True,
                thickness: int = 4) -> np.ndarray:
    """黑底 + 两条直白的"透视"车道线（消失点在 (van_x, -50)，线延伸到画面底边）。

    左线 k=-1.406、右线 k=+1.406：默认 ROI (0.25,0.50) 内两线不相交，中心 ≈ van_x。
    """
    img = np.zeros((H, W, 3), dtype=np.uint8)
    if left:
        cv2.line(img, (int(van_x), -50), (int(van_x - 320), 400), (255, 255, 255), thickness)
    if right:
        cv2.line(img, (int(van_x), -50), (int(van_x + 320), 400), (255, 255, 255), thickness)
    return img


def _detect(img: np.ndarray, **overrides) -> LaneResult:
    return LaneDetector(LaneParams(**overrides)).detect(img)


def test_symmetric_lane_center_at_target() -> None:
    r = _detect(_lane_image())
    assert r.both_sides, f"对称车道应双侧：{r}"
    assert r.center_x is not None and abs(r.center_x - 320.0) < 4.0, \
        f"中心应≈320，实际 {r.center_x}"
    assert r.error is not None and abs(r.error) < 4.0
    assert r.n_left >= 1 and r.n_right >= 1


def test_shifted_lanes_move_center() -> None:
    r = _detect(_lane_image(van_x=360.0))
    assert r.both_sides
    assert r.center_x is not None and abs(r.center_x - 360.0) < 5.0, \
        f"车道右移 40px，中心应≈360，实际 {r.center_x}"


def test_error_sign() -> None:
    assert _detect(_lane_image(van_x=380.0)).error > 0.0     # 中心在目标右边 → 正误差
    assert _detect(_lane_image(van_x=280.0)).error < 0.0


def test_left_only_border_fill() -> None:
    r = _detect(_lane_image(right=False))
    assert not r.both_sides and not r.lost and r.single_fill == "border", f"{r}"
    assert r.left_x is not None and r.right_x is None
    # 参考实现：center = (左线 x + 画面右边界 w−1) / 2
    expect = (r.left_x + (W - 1)) * 0.5
    assert r.center_x is not None and abs(r.center_x - expect) < 1e-6


def test_right_only_border_fill() -> None:
    r = _detect(_lane_image(left=False))
    assert r.single_fill == "border" and r.right_x is not None and r.left_x is None
    expect = (0.0 + r.right_x) * 0.5
    assert r.center_x is not None and abs(r.center_x - expect) < 1e-6


def test_single_mode_off_gives_no_center() -> None:
    r = _detect(_lane_image(right=False), single_mode="off")
    assert r.center_x is None and r.error is None
    assert r.single_fill == "off" and not r.lost      # 有单侧线，只是不给中心


def test_no_line_is_lost() -> None:
    r = _detect(np.zeros((H, W, 3), dtype=np.uint8))
    assert r.lost and r.center_x is None and r.n_left == 0 and r.n_right == 0


def test_slope_gate_rejects_horizontal_and_vertical() -> None:
    # 近水平亮条（横纹/反光）：|k|≈0 必须被闸门扔掉
    img = np.zeros((H, W, 3), dtype=np.uint8)
    cv2.line(img, (50, 180), (590, 180), (255, 255, 255), 4)
    r = _detect(img)
    assert r.lost, f"近水平线不得当选：{r}"
    # 近竖直亮条：dx≈0 被跳过 / |k| 超闸门
    img2 = np.zeros((H, W, 3), dtype=np.uint8)
    cv2.line(img2, (320, 100), (320, 400), (255, 255, 255), 4)
    r2 = _detect(img2)
    assert r2.lost, f"近竖直线不得当选：{r2}"


def test_roi_must_cover_lines() -> None:
    # 线只画在画面底部 y400~479：默认 ROI（y120~240）罩不到 → lost
    img = np.zeros((H, W, 3), dtype=np.uint8)
    cv2.line(img, (300, 400), (120, 479), (255, 255, 255), 4)     # 左线 k=-0.44
    cv2.line(img, (340, 400), (560, 479), (255, 255, 255), 4)     # 右线 k=+0.36
    assert _detect(img).lost
    r = _detect(img, roi_top=0.83, roi_bottom=1.0)
    assert r.both_sides, f"ROI 罩到底部线应双侧：{r}"
    assert r.center_x is not None and 250.0 <= r.center_x <= 380.0


def test_min_lines_gate() -> None:
    img = _lane_image(right=False)                      # 只有一条线 → 线段数远小于 8
    r_gated = _detect(img, min_lines=8)
    assert r_gated.lost, f"min_lines=8 应判 lost：{r_gated}"
    r_free = _detect(img)
    assert not r_free.lost


def test_adaptive_canny_stays_clamped() -> None:
    rng = np.random.default_rng(7)
    noise = rng.integers(0, 255, (H, W, 3), dtype=np.uint8)
    frame = cv2.addWeighted(noise, 0.7, _lane_image(), 0.3, 0)
    det = LaneDetector(LaneParams(canny_adaptive=True))
    for _ in range(10):
        det.detect(frame)
        assert CANNY_LOW_MIN <= det.canny_low <= CANNY_LOW_MAX
        assert CANNY_HIGH_MIN <= det.canny_high <= CANNY_HIGH_MAX


def test_scan_band_matches_roi_by_default() -> None:
    r = _detect(_lane_image())
    assert r.both_sides and r.center_x is not None


def test_profile_presets() -> None:
    assert PROFILES["demo"]["min_lines"] == 8
    assert abs(float(PROFILES["oldcode"]["roi_top"]) - 0.50) < 1e-9
    assert abs(float(PROFILES["demo"]["roi_top"]) - 300 / 480.0) < 1e-9


def test_summarize_counts() -> None:
    rows = [LaneResult(center_x=320.0, error=0.0, both_sides=True, n_left=3, n_right=2),
            LaneResult(center_x=360.0, error=40.0, both_sides=True, n_left=1, n_right=1),
            LaneResult(center_x=None, lost=True)]
    st = summarize(rows)
    assert st["n"] == 3 and st["both"] == 2 and st["lost"] == 1
    assert abs(st["c_med"] - 340.0) < 1e-9


if __name__ == "__main__":
    fns = sorted((v for k, v in globals().items()
                  if k.startswith("test_") and callable(v)
                  and getattr(v, "__module__", None) == __name__), key=lambda f: f.__name__)
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"✅ {fn.__name__}")
        except Exception as exc:
            failed += 1
            print(f"❌ {fn.__name__}: {exc!r}")
    print(f"test_lane_official: all {len(fns) - failed} passed"
          if not failed else f"test_lane_official: {len(fns) - failed}/{len(fns)} passed")
    sys.exit(1 if failed else 0)