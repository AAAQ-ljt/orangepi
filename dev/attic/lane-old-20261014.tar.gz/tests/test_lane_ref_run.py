"""循迹实跑状态机的**端到端**测试：假摄像头 + 假蓝板，不碰硬件、不碰真实摄像头。

为什么要有这个文件
------------------
实跑脚本的"状态机 + 退出路径"是最贵的一段代码：到操场才发现崩了，一整趟就白跑。
上一版就是在这里出的问题（退出时 `int(None)` / `detect(None)` 两个 Traceback、
探路阶段舵角没回中位）。这里用假帧把**整条流程**跑一遍：

    起步前自检窗口 → 蓝板武装 → 板移开 → 探路(acquire) → 跟线(track)
    → 丢线维持(hold) → 超时(lost) → 自行停车收尾

断言的是"流程能走完且阶段齐全"，不校验具体数值（数值由 test_lane_ref.py 的纯函数测试覆盖）。

跑法：
    cd dev && PYTHONPATH=. python tests/test_lane_ref_run.py
"""
from __future__ import annotations

import contextlib
import os
import sys
import tempfile
import time

import cv2
import numpy as np

from config import settings

# ---------------------------------------------------------------- 假图几何（与现场标定解耦）
# 本文件的假图几何是**固定的**（车道线画在一段固定的 y 上），所以这里显式把 ROI/前瞻带
# 钉在这段几何上：现场换镜头/改 site.yaml 时，算法用例不该集体翻红（现场标定的对错由
# 端到端自检 + 操场实跑负责）。2026-10-13：镜头压低后现场档改成 0.15~0.75 / 前瞻 0.17~0.26，
# 与本文件假图几何不同 —— 这就是要在这里钉死的原因。
settings.LANE_ROI_TOP_RATIO = 0.35
settings.LANE_ROI_BOTTOM_MARGIN = 200
settings.LANE_LOOK_TOP_RATIO = 0.35
settings.LANE_LOOK_BOTTOM_RATIO = 0.48

import scripts.lane_ref_test as lt

W, H = 640, 480


def _lane_frame(shift: int = 0, left: bool = True, right: bool = True) -> np.ndarray:
    """红棕底 + 两条斜白线（画面中下部没有线 → 体检会判不够用，但检测能锁住成对）。"""
    frame = np.zeros((H, W, 3), dtype=np.uint8)
    frame[:, :, 2], frame[:, :, 1], frame[:, :, 0] = 120, 45, 35
    yt, yb, y_ref = int(H * 0.30), int(H * 0.60), int(H * 0.60)
    sides = [(160 + shift, +1)] if left else []
    sides += [(590 + shift, -1)] if right else []
    for x_ref, sign in sides:
        for y in range(yt, yb):
            x = int(round(x_ref - sign * 0.972 * (y - y_ref)))
            frame[y, max(0, x - 4):x + 5] = 225
    return frame


def _board_frame() -> np.ndarray:
    """蓝板挡在下摄正前方（盖住 START_GATE_ROI 的大部分）。"""
    frame = _lane_frame()
    frame[150:400, 150:500] = (255, 0, 0)        # BGR：纯蓝
    return frame


def _blank_frame() -> np.ndarray:
    """没有线的画面（模拟"线丢了"）。"""
    frame = np.zeros((H, W, 3), dtype=np.uint8)
    frame[:, :, 2], frame[:, :, 1], frame[:, :, 0] = 120, 45, 35
    return frame


def _cone_high_frame(cone_dx: int = 0) -> np.ndarray:
    """锥桶在画面上部（y 70~170）：默认 CONE_GATE_ROI(0.35) 切不到。

    用**淡蓝** (200,170,120)：dominance=B−max(R,G)=30 < 35，不会被发车闸门当蓝板
    （真实锥桶 S≈70 也是低饱和，此口径一致）；仍在锥桶 HSV (70,30,150)~ 内可检出。
    cone_dx：只横向平移锥桶（任务 A 三位置场景用；线不动）。
    """
    frame = _lane_frame()
    frame[70:170, 295 + cone_dx:385 + cone_dx] = (200, 170, 120)
    return frame


def _cone_frame(shift: int = 0, size: int = 90) -> np.ndarray:
    """红棕底 + 双斜白线 + 一个蓝色锥桶块（下摄视角：锥桶在画面中下部，ROI 内）。"""
    frame = _lane_frame(shift=shift)
    cx, bottom = 340 + shift, 420
    frame[bottom - size:bottom, cx - size // 2:cx + size // 2] = (255, 140, 60)  # BGR 偏蓝
    return frame


class _FakeCap:
    """假摄像头：按顺序吐帧，每帧等一小会儿（模拟 15FPS 的时间流逝）。"""

    def __init__(self, frames, delay: float = 0.03):
        self.frames = list(frames)
        self.delay = delay
        self.i = 0
        self.released = False

    def read(self):
        if self.i >= len(self.frames):
            return False, None
        time.sleep(self.delay)
        f = self.frames[self.i]
        self.i += 1
        return True, f.copy()

    def release(self):
        self.released = True


def _run(frames, extra_args):
    """用假摄像头跑一遍 main()，返回 (rc, 会话目录, CSV 文本)。"""
    tmp = tempfile.mkdtemp(prefix="lane_run_")
    cap = _FakeCap(frames)
    saved = (lt.open_camera, lt.camera_exclusive)
    lt.open_camera = lambda *a, **k: cap                 # 不碰真实摄像头
    lt.camera_exclusive = lambda *a, **k: contextlib.nullcontext()
    argv = sys.argv
    csv = os.path.join(tmp, "run.csv")
    sys.argv = ["lane_ref_test.py", "--no-motor", "--save-dir", tmp, "--log-csv", csv,
                "--save-every-s", "0", "--setup-frames", "4", "--print-every", "100",
                "--no-save-site", "--max-seconds", "30",
                "--read-fail-s", "2"] + list(extra_args)
    rc = 1
    try:
        rc = lt.main()
    finally:
        sys.argv = argv
        lt.open_camera, lt.camera_exclusive = saved
    with open(csv, "r", encoding="utf-8") as fh:
        return rc, tmp, fh.read()


def test_full_state_machine_walks_all_phases():
    """走完一整条流程：自检 → 武装 → 探路 → 跟线 → 维持 → 丢线停车（不带异常退出）。"""
    frames = ([_lane_frame()] * 6          # 起步前自检窗口（车静止、镜头看赛道）
              + [_board_frame()] * 4       # 蓝板出现 → 武装（3 帧确认）
              + [_blank_frame()] * 2       # 板移开但还没看到线 → 探路 acquire
              + [_lane_frame()] * 12       # 看到线 → 跟线 track
              + [_blank_frame()] * 60)     # 线丢了 → 维持 hold → 超时 lost → 停车
    rc, tmp, csv = _run(frames, ["--acquire-s", "0.15", "--hold-s", "0.2"])
    assert rc == 0, f"实跑应当正常返回 0，实际 {rc}"
    head = csv.splitlines()[0]
    assert "error_filt" in head and "target_px" in head, "CSV 要带复盘用的新列"
    phases = set()
    for line in csv.splitlines()[1:]:
        parts = line.split(",")
        if len(parts) > 1:
            phases.add(parts[1])
    for need in ("stop", "acquire", "track", "hold", "lost"):
        assert need in phases, f"阶段 {need} 没走到（实际 {sorted(phases)}）"
    assert os.path.exists(os.path.join(tmp, "summary.json")), "应当落盘 summary.json"
    setup_dir = os.path.join(tmp, "setup")
    assert os.path.isdir(setup_dir), "起步前自检的帧要存下来（复盘证据）"


def test_fps_column_and_pinned_rate():
    """★ 帧率口径的端到端接线（2026-10-12）：

    ① 默认（自动）：CSV 的 fps 列要有实测值、summary.json 里要带上它的分布；
    ② `--fps 30`：钉死口径后控制律按 30fps 折算（帧数类参数也要跟着折），不能崩、不能停摆。
    桩摄像头的 `cap.read()` 是真 sleep（delay=0.03 → ~33fps），所以自动档看到的就是 ~30 上下。
    """
    import json
    frames = ([_lane_frame()] * 6 + [_board_frame()] * 4 + [_blank_frame()] * 2
              + [_lane_frame()] * 12 + [_blank_frame()] * 40)
    rc, tmp, csv = _run(frames, ["--acquire-s", "0.15", "--hold-s", "0.2"])
    assert rc == 0, f"自动档应当正常返回 0，实际 {rc}"
    head = csv.splitlines()[0].split(",")
    assert "fps" in head, "CSV 必须落实测帧率（复盘要看帧率稳不稳）"
    idx = head.index("fps")
    vals = [float(line.split(",")[idx]) for line in csv.splitlines()[1:]
            if len(line.split(",")) > idx and line.split(",")[idx]]
    assert vals and all(v > 0 for v in vals), f"fps 列必须有正值，实际 {vals[:5]}"
    assert 5.0 < max(vals) < 120.0, f"fps 列数值离谱：{max(vals)}"
    with open(os.path.join(tmp, "summary.json"), "r", encoding="utf-8") as fh:
        summary = json.load(fh)
    assert summary.get("fps", {}).get("n", 0) > 0, "summary.json 要带帧率分布"

    # ② 钉死 30fps：走的是 rate.pin 分支（不再自动测量），全程照常跑完
    rc2, tmp2, csv2 = _run(frames, ["--acquire-s", "0.15", "--hold-s", "0.2", "--fps", "30"])
    assert rc2 == 0, f"钉死帧率也应当正常返回 0，实际 {rc2}"
    idx2 = csv2.splitlines()[0].split(",").index("fps")
    vals2 = [float(line.split(",")[idx2]) for line in csv2.splitlines()[1:]
             if len(line.split(",")) > idx2 and line.split(",")[idx2]]
    assert vals2 and all(abs(v - 30.0) < 1e-6 for v in vals2), \
        f"--fps 30 时 CSV 的 fps 列应当恒为 30，实际 {sorted(set(vals2))[:3]}"


def test_cones_trigger_s_avoid_then_resume():
    """锥桶出现 → S 型避让（avoid1/resume/avoid2）→ 回 track；绕行是低速、有兜底。"""
    frames = ([_lane_frame()] * 6          # 自检窗口
              + [_board_frame()] * 4       # 蓝板武装
              + [_blank_frame()] * 2       # 探路
              + [_lane_frame()] * 8        # 跟线
              + [_cone_frame()] * 20       # 锥桶出现（防抖 3 帧 → avoid1）
              + [_lane_frame()] * 20       # 锥桶移开 → 回 track
              + [_blank_frame()] * 40)     # 丢线收尾
    rc, tmp, csv = _run(frames, ["--cone-method", "hsv", "--cone-avoid",
                                 "--cone-avoid-s", "0.15", "--cone-resume-s", "0.1",
                                 "--acquire-s", "0.15", "--hold-s", "0.2"])
    assert rc == 0, f"带锥桶的实跑应当正常返回 0，实际 {rc}"
    phases = set(line.split(",")[1] for line in csv.splitlines()[1:] if line.count(",") > 2)
    for need in ("avoid1", "resume", "avoid2"):
        assert need in phases, f"绕行阶段 {need} 没走到（实际 {sorted(phases)}）"
    assert "track" in phases, "绕行结束后应回到循迹"


def test_cone_avoid_immune_to_big_error_guard():
    """绕行豁免跑偏保护（10-11 修复回归）。

    场景（复刻审查复现实验）：误差恒 +79px（用 --no-auto-target 把目标点偏置到 296，
    线在画面正中、质量 1.00）——修复前 big_err 在绕行期间照常累积，S 型走到一半被
    guard 停死、整次行程结束；修复后绕行期间不更新保护、进出各 reset，S 三段完整。
    时序照真实复现：锥桶块先被发车闸门当板挡几帧（stop，tracker 无条件攒 present），
    "锥桶移开"（线帧）后 avoid1 启动。
    """
    frames = ([_lane_frame()] * 6            # 自检窗口
              + [_board_frame()] * 3         # 板武装
              + [_cone_frame()] * 4          # 锥桶出现（闸门判 blocked；tracker 攒 present=3+）
              + [_lane_frame()] * 45         # "移开锥桶"：driving=True + present 余温 → S 型；
                                             # 误差 79 持续 → 旧代码在 avoid 里几帧就被 guard
              + [_blank_frame()] * 40)       # 丢线收尾（无中心 → 不喂保护）
    rc, _tmp, csv = _run(frames, ["--cone-method", "hsv", "--cone-avoid",
                                  "--cone-avoid-s", "0.6", "--cone-resume-s", "0.4",
                                  "--no-auto-target", "--target-ratio", "0.4625"])
    assert rc == 0
    phases = [line.split(",")[1] for line in csv.splitlines()[1:] if line.count(",") > 2]
    for need in ("avoid1", "resume", "avoid2"):
        assert need in phases, f"S 型三段应完整走完，实际 {phases}"
    # ★ 结论只看 guard 出现在"哪"：本用例全程误差恒 79px，S 走完后剩下的线帧迟早会让
    #   big_err 的振荡判据（窗口 ≥6 帧、占比 ≥60%）触发——那是**正确行为**（真跑偏），
    #   且触发早晚取决于机器速度（每帧 dt 决定 S 消耗掉多少线帧）。
    #   所以不断言"不得出现 guard"，只要求它**不得在 S 走完之前**出现：
    #   豁免失效时 guard 会在 avoid1 中途就打进来（此时 resume/avoid2 还没出现）。
    if "guard" in phases:
        assert phases.index("guard") > phases.index("avoid2"), \
            f"S 未走完就被跑偏保护打断（豁免失效）：{phases}"


def test_cone_cooldown_gates_respawn():
    """CONE_COOLDOWN_S 接线（10-11）：锥桶常驻视野时，第二轮 avoid1 必须等冷却期满。"""
    frames = ([_lane_frame()] * 6
              + [_board_frame()] * 3
              + [_cone_high_frame()] * 110      # 锥桶常驻：够 S1(1.6s) + 冷却 + S2 完整
              + [_blank_frame()] * 80)          # 丢线收尾（第三轮不会再启动 → 自然 lost）
    rc, _tmp, csv = _run(frames, ["--cone-method", "hsv", "--cone-avoid",
                                  "--cone-avoid-s", "0.6", "--cone-resume-s", "0.4",
                                  "--cone-roi-top", "0.05", "--cone-cooldown-s", "1.0"])
    assert rc == 0
    rows = [(float(r[0]), r[1]) for r in
            (line.split(",") for line in csv.splitlines()[1:]) if len(r) > 2]
    starts = []
    for i, (t, ph) in enumerate(rows):
        if ph == "avoid1" and (i == 0 or rows[i - 1][1] != "avoid1"):
            starts.append(t)
    assert len(starts) >= 2, f"锥桶常驻应触发至少两轮 S，实际起点 {starts}"
    # 起点差 = S 总时长(0.6+0.4+0.6) + 冷却 1.0s ≈ 2.6s
    gap = starts[1] - starts[0]
    assert 2.3 <= gap < 3.6, f"两轮 avoid1 间隔 {gap:.2f}s 应≈ S时长+冷却(2.6s)"


def test_cone_cli_overrides_reach_detector():
    """--cone-roi-top / --cone-hsv-* 必须真的进检测器（10-11 覆盖项透传回归）。"""
    frames = ([_lane_frame()] * 6
              + [_board_frame()] * 3
              + [_cone_high_frame()] * 30
              + [_blank_frame()] * 30)
    base = ["--cone-method", "hsv", "--cone-avoid",
            "--cone-avoid-s", "0.6", "--cone-resume-s", "0.4"]
    rc, _t, csv = _run(frames, base)
    assert "avoid1" not in [r[1] for r in
                            (l.split(",") for l in csv.splitlines()[1:]) if len(r) > 2],         "默认 ROI(0.35) 切掉高处锥桶 → 不应绕行"
    rc, _t, csv = _run(frames, base + ["--cone-roi-top", "0.05"])
    assert "avoid1" in [r[1] for r in
                        (l.split(",") for l in csv.splitlines()[1:]) if len(r) > 2],         "--cone-roi-top 0.05 后应检出并绕行"
    rc, _t, csv = _run(frames, base + ["--cone-roi-top", "0.05",
                                       "--cone-hsv-low", "1,1,1",
                                       "--cone-hsv-high", "2,2,2"])
    assert "avoid1" not in [r[1] for r in
                            (l.split(",") for l in csv.splitlines()[1:]) if len(r) > 2],         "故意错的 HSV 不应检出"


def test_cone_avoid_direction_respects_steer_sign():
    """实车口径（site.yaml steer_sign=-1，角度增大=左转）下绕行方向必须正确（四轮审查补）。

    本地默认跑在 settings 的 +1 口径；实车是 -1。方向公式 angle = center ± first*sign*deg
    必须在两种符号下都镜像正确——本用例把**实车符号**下的方向契约锁死：
    first_dir=left → avoid1 转左（角度更大），avoid2 转右；first_dir=right 正好相反。
    """
    frames = ([_lane_frame()] * 6
              + [_board_frame()] * 3
              + [_cone_high_frame()] * 30
              + [_blank_frame()] * 30)
    for first, a1_gt_mid in (("left", True), ("right", False)):
        rc, _tmp, csv = _run(frames, ["--cone-method", "hsv", "--cone-avoid",
                                      "--cone-avoid-s", "0.5", "--cone-resume-s", "0.3",
                                      "--cone-roi-top", "0.05",
                                      "--steer-sign", "-1", "--cone-first-dir", first])
        assert rc == 0
        rows = [(l.split(",")[1], float(l.split(",")[6])) for l in
                csv.splitlines()[1:] if l.count(",") > 6]
        a1 = [a for p, a in rows if p == "avoid1"]
        a2 = [a for p, a in rows if p == "avoid2"]
        mid = [a for p, a in rows if p == "resume"]
        assert a1 and a2 and mid, (
            f"应触发完整 S 型（first_dir={first}），实际相位 {sorted(set(p for p, _ in rows))}")
        assert (a1[0] > mid[0]) is a1_gt_mid, \
            f"first_dir={first}: avoid1 相对中位方向错（{a1[0]:.0f} vs 中位 {mid[0]:.0f}）"
        assert (a2[0] < mid[0]) is a1_gt_mid, \
            f"first_dir={first}: avoid2 应与 avoid1 反向（{a2[0]:.0f} vs 中位 {mid[0]:.0f}）"


def test_analyze_image_respects_cone_overrides():
    """P1 回归（10-11）：--image 单图路径必须接收 roi/hsv 覆盖项，不能读默认值。"""
    import contextlib
    import io as _io
    import tempfile
    tmp = tempfile.mkdtemp(prefix="cone_img_")
    path = os.path.join(tmp, "high_cone.jpg")
    cv2.imencode(".jpg", _cone_high_frame())[1].tofile(path)
    for extra, expect in (([], "部署 ROI 内无"),
                          (["--cone-roi-top", "0.05"], "锥桶(hsv): x=")):
        argv_back = sys.argv
        sys.argv = (["lane_ref_test.py", "--image", path, "--cone-method", "hsv"]
                    + extra)
        buf = _io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                lt.main()
        finally:
            sys.argv = argv_back
        out = buf.getvalue()
        assert expect in out, f"{extra} 时输出应含 {expect!r}，实际：{out[-200:]}"


def test_cone_avoid_side_from_position():
    """任务 A（10-11）：按锥桶横向位置选绕行侧——偏右→左绕、偏左→右绕、居中→默认 left。

    实车口径（--steer-sign -1，角度增大=左转）：left → avoid1 角度大于中位，right 小于。
    锥块中心（340+dx） vs 自检目标点（≈375）：dx=0 居中（差 35 < 容差 60）。
    """
    def run_with(dx):
        frames = ([_lane_frame()] * 6 + [_board_frame()] * 3
                  + [_cone_high_frame(cone_dx=dx)] * 40 + [_blank_frame()] * 30)
        return _run(frames, ["--cone-method", "hsv", "--cone-avoid",
                             "--cone-avoid-s", "0.5", "--cone-resume-s", "0.3",
                             "--cone-roi-top", "0.05", "--steer-sign", "-1"])

    def a1_gt_mid(csv):
        rows = [(l.split(",")[1], float(l.split(",")[6])) for l in
                csv.splitlines()[1:] if l.count(",") > 6]
        a1 = [a for p, a in rows if p == "avoid1"]
        mid = [a for p, a in rows if p == "resume"]
        assert a1 and mid, "需要 avoid1 与 resume 相位"
        return sum(a1) / len(a1) > sum(mid) / len(mid)

    rc, _t, csv = run_with(200)      # 锥在画面右侧（偏右）→ 左绕
    assert rc == 0
    assert a1_gt_mid(csv), "偏右锥应左绕（avoid1 角度 > 中位）"
    rc, _t, csv = run_with(-200)     # 锥偏左 → 右绕
    assert rc == 0
    assert not a1_gt_mid(csv), "偏左锥应右绕（avoid1 角度 < 中位）"
    rc, _t, csv = run_with(0)        # 居中（差 35 < 容差）→ 默认 left
    assert rc == 0
    assert a1_gt_mid(csv), "居中锥应走默认 left（avoid1 角度 > 中位）"


def test_cone_avoid_off_never_enters_avoid():
    """没开 --cone-avoid 时，即使检测到锥桶也不绕行（默认行为不变）。"""
    frames = ([_lane_frame()] * 6
              + [_board_frame()] * 4
              + [_blank_frame()] * 2
              + [_lane_frame()] * 4
              + [_cone_frame()] * 30
              + [_lane_frame()] * 10
              + [_blank_frame()] * 40)
    rc, tmp, csv = _run(frames, ["--cone-method", "hsv",
                                 "--acquire-s", "0.15", "--hold-s", "0.2"])
    assert rc == 0
    phases = set(line.split(",")[1] for line in csv.splitlines()[1:] if line.count(",") > 2)
    assert not ({"avoid1", "avoid2"} & phases), (
        f"未开 --cone-avoid 不应绕行，实际出现了 {sorted(phases & {'avoid1', 'resume', 'avoid2'})}")


def test_cone_stop_blocks_then_resumes():
    """--cone-stop：检测到锥桶 → 停车；锥桶移开 → 继续前进（实验室先验检测用）。"""
    frames = ([_lane_frame()] * 6          # 自检窗口
              + [_board_frame()] * 4       # 蓝板武装
              + [_blank_frame()] * 2       # 探路
              + [_lane_frame()] * 6        # 跟线
              + [_cone_frame()] * 15       # 锥桶出现 → 停车（防抖 3 帧后 cone_stopped）
              + [_lane_frame()] * 10       # 锥桶移开 → 恢复前进（回 track）
              + [_blank_frame()] * 40)     # 丢线收尾
    rc, tmp, csv = _run(frames, ["--cone-method", "hsv", "--cone-stop",
                                 "--acquire-s", "0.15", "--hold-s", "0.2"])
    assert rc == 0, f"实验室停锥桶模式应当正常返回 0，实际 {rc}"
    phases = [line.split(",")[1] for line in csv.splitlines()[1:] if line.count(",") > 2]
    if "track" in phases:
        first_track = phases.index("track")
        # 锥桶段停住：track 之后出现 stop
        stop_after = next((i for i in range(first_track + 1, len(phases))
                           if phases[i] == "stop"), -1)
        assert stop_after > first_track, "锥桶出现后应有停车（stop 相位）"
        # 锥桶移开后恢复：stop 之后再次出现 track
        track_after = next((i for i in range(stop_after + 1, len(phases))
                            if phases[i] == "track"), -1)
        assert track_after > stop_after, "锥桶移开后应恢复前进（track 相位）"


def test_never_blocks_means_never_drives():
    """没见过蓝板 → 全程 stop，绝不动车（安全红线）。"""
    rc, _tmp, csv = _run([_lane_frame()] * 12, [])
    assert rc in (0, 1)
    phases = set(line.split(",")[1] for line in csv.splitlines()[1:] if line.count(",") > 2)
    assert phases <= {"stop"}, f"没有蓝板时只能停车，实际阶段 {sorted(phases)}"


# ------------------------------------------------------------------ 斑马线档（--zebra-stop）
def _zebra_frame() -> np.ndarray:
    """暗底 + 5 条白色横条（在 ZEBRA_ROI 内 y≥168；底面无车道线避免串扰）。"""
    frame = _blank_frame()
    for y in range(200, 380, 36):
        cv2.rectangle(frame, (80, y), (560, y + 14), (255, 255, 255), -1)
    return frame


def test_zebra_stop_triggers_then_resumes():
    """--zebra-stop：跟线中遇到斑马线 → 进入 zebra 停车相位 → 停够后恢复 track。"""
    frames = ([_lane_frame()] * 6          # 起步前自检窗口
              + [_board_frame()] * 3       # 见板武装
              + [_lane_frame()] * 6        # 移开板 → 放行跟线
              + [_zebra_frame()] * 6       # 斑马线：连续 3 帧触发 → 停车
              + [_lane_frame()] * 20       # 停够 0.4s 后应恢复循迹
              + [_blank_frame()] * 40)     # 丢线收尾（自然 lost，rc=0）
    rc, _tmp, csv = _run(frames, ["--zebra-stop", "--zebra-seconds", "0.4"])
    assert rc == 0
    rows = [line.split(",") for line in csv.splitlines()[1:] if line.count(",") > 2]
    phases = [r[1] for r in rows]
    assert "zebra" in phases, f"应进入斑马线停车相位，实际 {phases}"
    zi = phases.index("zebra")
    assert "track" in phases[zi + 1:], "停够后应恢复循迹（track 相位）"


def test_zebra_off_never_enters_zebra():
    """不开 --zebra-stop：纯循迹行为不变（斑马线画面也不触发停车）。"""
    frames = ([_lane_frame()] * 6
              + [_board_frame()] * 3
              + [_lane_frame()] * 6
              + [_zebra_frame()] * 6
              + [_lane_frame()] * 4
              + [_blank_frame()] * 40)
    rc, _tmp, csv = _run(frames, [])
    assert rc == 0
    assert "zebra" not in csv.splitlines()[0:], "默认必须不触发斑马线停车"


def test_board_too_early_is_handled():
    """一开机板就挡着 → 自检跳过、给告警，但流程不能崩（现场很容易这么操作）。"""
    rc, _tmp, csv = _run([_board_frame()] * 4 + [_lane_frame()] * 20, [])
    assert rc in (0, 1), "板挡得太早也要能正常收尾"
    phases = set(line.split(",")[1] for line in csv.splitlines()[1:] if line.count(",") > 2)
    assert "track" in phases, "板移开后仍应能跟线"


def test_single_side_lane_keeps_running():
    """只看到一侧线时：靠半宽先验兜底继续跟线（不是"一丢线就停"）。"""
    half_lane = _lane_frame(left=True, right=False)   # 只画左线。别用"擦列"法：
    #   右线 x<500 的残段会留幻影边缘，车端旧 cv2 的 HoughLinesP 把它凑成假对
    frames = ([_lane_frame()] * 6 + [_board_frame()] * 4 + [half_lane] * 25)
    # 这一条不需要自检扫带（省时间），直接测"单侧还能不能走"
    rc, _tmp, csv = _run(frames, ["--acquire-s", "0.15", "--hold-s", "0.2",
                                  "--no-auto-roi", "--no-auto-look"])
    assert rc in (0, 1)
    phases = set(line.split(",")[1] for line in csv.splitlines()[1:] if line.count(",") > 2)
    assert "track" in phases, f"单侧兜底应当仍能进 track，实际 {sorted(phases)}"
    singles = [ln for ln in csv.splitlines()[1:] if ln.split(",")[13:14] == ["0"]]
    assert singles, "应当出现过【单侧】帧（both_sides=0）"


def test_single_hold_keeps_speed_and_labels_phase():
    """`--single-hold`：单侧兜底帧不跟推算中心（回中位），且**速度取 --single-speed-us**。

    回归（2026-10-11 假帧复跑实锤）：`angle/out_us/phase` 这几条原先写在 if/else **外面**，
    会把 single 分支刚设好的 `out_us`(=--single-speed-us) 与 `phase="single"` 覆盖掉
    → 该参数完全失效（单侧帧退化成 `floor_pulse` = base+speed_slow）、CSV 里没有 single 阶段、
    A/D 两档对照会得出"这参数没用"的错误结论。本用例锁住修复后的行为。
    """
    half = _lane_frame(left=True, right=False)   # 只画左线 = 单侧兜底帧。不要用
    #   "擦掉 x≥500"构造：右线 x<500 的残段是幻影边缘，车端旧 cv2 的 HoughLinesP
    #   会把它和左线凑成假对（both_sides=1，10 帧里 8 帧）→ 用例变抛硬币
    #   （2026-10-11 串口实测：本地 cv2 5.0 全过、车上 17/19 挂这条）。
    frames = [_lane_frame()] * 6 + [_board_frame()] * 4 + [half] * 10 + [_lane_frame()] * 10
    rc, _tmp, csv = _run(frames, ["--acquire-s", "0.15", "--hold-s", "0.2",
                                  "--no-auto-roi", "--no-auto-look", "--single-hold",
                                  "--single-speed-us", "1560", "--speed-us", "1580",
                                  "--speed-slow", "-10"])
    assert rc in (0, 1)
    rows = [ln.split(",") for ln in csv.splitlines()[1:] if ln.count(",") > 10]
    singles = [r for r in rows if r[1] == "single"]
    assert singles, f"应当出现 single 阶段，实际阶段 {sorted(set(r[1] for r in rows))}"
    assert {r[7] for r in singles} == {"1560"}, \
        f"单侧帧脉宽必须取 --single-speed-us(1560)，实际 {sorted({r[7] for r in singles})}"
    center = float(lt.settings.SERVO_CENTER_ANGLE)
    assert {float(r[6]) for r in singles} == {center}, \
        f"单侧帧舵角必须回中位({center})，实际 {sorted({float(r[6]) for r in singles})}"


def test_camera_dead_exits_cleanly():
    """摄像头一直不给画面 → 在 --read-fail-s 内报错退出（rc=1），不空转到 --max-seconds；
    而且安全层照常收尾（summary 落盘）。"""
    t0 = time.time()
    rc, tmp, csv = _run([], ["--read-fail-s", "2"])
    assert rc == 1, f"读不到画面应当报错退出，实际 rc={rc}"
    assert time.time() - t0 < 20, "不该傻等到 --max-seconds"
    assert os.path.exists(os.path.join(tmp, "summary.json")), "即使报错退出也要落盘与收尾"


def test_run_guard_trip_does_not_crash():
    """跑偏保护在"读数质量不够（err_c=None）但原始误差很大"时触发 → 不能崩。

    2026-09-22 落地实测崩过：`f"{err_c:+.1f}"` 撞上 NoneType。
    只有一侧白线时，半宽用**种子**推出中心（质量 0.25 < 0.28）→ 不进控制器，
    但原始误差很大 → 正好走这条路径。
    """
    one_side = [_lane_frame(right=False)] * 20          # 只有左线 → 质量 0.25
    frames = [_lane_frame()] * 6 + [_board_frame()] * 4 + one_side
    rc, tmp, csv = _run(frames, ["--err-stop-px", "40", "--err-stop-s", "0.2",
                                 "--no-auto-roi", "--no-auto-look"])
    assert rc in (0, 1), f"不该崩（rc={rc}）"
    summary = os.path.join(tmp, "summary.json")
    assert os.path.exists(summary), "即使触发保护也要正常收尾落盘"


def test_session_dir_is_created_before_csv():
    """**会话目录还不存在时也要能跑**（默认就是这种情形：CSV 写在 <save_dir>/run.csv）。

    2026-09-22 实验室实测的崩溃：`Recorder` 先 `open(csv)` 后 `makedirs` →
    车上第一次跑就 FileNotFoundError。本地集成测试当时用的是**已存在**的临时目录，
    所以没抓到 —— 这条测试专门盯着"目录必须先建"。
    """
    from scripts.lane_ref_test import Recorder
    base = tempfile.mkdtemp(prefix="lane_fresh_")
    fresh = os.path.join(base, "lane_20260922_165613")       # 故意不让它存在
    assert not os.path.exists(fresh)
    rec = Recorder(os.path.join(fresh, "run.csv"), fresh, 0.0, 10)
    try:
        assert os.path.isdir(fresh), "会话目录应当被建出来"
        assert rec._fh is not None, "CSV 应当能打开"
        assert os.path.isfile(os.path.join(fresh, "run.csv"))
        assert os.path.isdir(os.path.join(fresh, "setup")), "setup 子目录也要建"
        rec.row(0.1, "track", None, None, 375.0, 90.0, 1500.0, 0.0)   # 写一行不能崩
    finally:
        rec.close()
    # 目录建不出来（父路径是个文件）→ 只告警、不崩车
    bad_parent = os.path.join(base, "not_a_dir")
    with open(bad_parent, "w", encoding="utf-8") as fh:
        fh.write("x")
    rec2 = Recorder(os.path.join(bad_parent, "sub", "run.csv"),
                    os.path.join(bad_parent, "sub"), 0.0, 10)
    try:
        assert rec2._fh is None and rec2.save_dir == "", "打不开时应当降级成『不落盘』而不是抛异常"
        rec2.row(0.1, "track", None, None, 375.0, 90.0, 1500.0, 0.0)
    finally:
        rec2.close()


if __name__ == "__main__":
    # 10-11 修：改用全量收集（此前是手写白名单——新增用例忘记登记就会静默不跑）
    fns = [v for k, v in sorted(globals().items())
           if k.startswith("test_") and callable(v)
           and getattr(v, "__module__", None) == __name__]
    for fn in fns:
        fn()
        print(f"  ✅ {fn.__name__}")
    print(f"test_lane_ref_run: all {len(fns)} passed")
