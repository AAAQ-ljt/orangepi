"""照 2026 官方样例 + 2025 oldCode 的循迹扫线 —— 全新独立实现（纯离线，不碰硬件）。

用途：在实拍视频帧/视频文件上跑扫线，出叠加图与统计，**用来调参**。不含摄像头、
电机、UDP、状态机；参数全部走命令行，改参不用改代码。

链路（与两份参考实现逐参数对齐）
--------------------------------
    ROI 裁剪 → 灰度 → GaussianBlur(5,5,0.5) → Canny(60,140)
    → HoughLinesP(rho=1, theta=0.05rad, thr=50, minLen=30, maxGap=5)
    → 斜率闸门分左右（k 符号），每侧取 |k| 最大一条
    → 在扫描行带内逐行求左右交点中点、取平均 = center_x
    → 单侧：缺的一侧代画面边界（左缺→0 / 右缺→w−1）——**参考实现原样**
    → 两侧都没有线 → lost
    error = center_x − target_x

出处
----
- 2026 官方样例：比赛资料/…/14.5G车室外赛代码＋一镜到底开箱/demo(中文注释).cpp
  （ROI y300~480；Canny 60/140 自适应 ±2/±4；Hough 1/0.05/50/30/5；斜率 0.25~2.0；
   逐行中点平均；单侧代边界；线数 <8 判停 MIN_LINE_COUNT=8；目标 = 画面中心 320）
- 2025 oldCode：train/opencv-level1/reference_oldCode/src/vision/vision.cpp::picture()
  （ROI = 高度的 0.50~0.85；扫描行 130~230；误差 = ave_x − cols/2；其余同上）

与参考实现的有意偏离（全部登记在此）
------------------------------------
1. 工作分辨率 = 原图 640×480，**不做 320 缩放**；参考里 320×96 / 320×240 的口径
   一律换算到整帧像素坐标，避免两套坐标系混用（175/226/248 这类数字不进本脚本）；
2. 扫描行带可独立于 ROI 配置（oldCode 本来就是"ROI 拟合、扫描行另给"）；
3. 扫描带内两线**交叉**的行跳过不计（demo 是交换 lx/rx；交叉通常意味着配对错了，
   跳过更保守），交叉行数记进 notes/统计；
4. Canny 自适应是"本帧用当前值、调一步给下一帧"（参考行为），默认**关闭**（见下）。

⚠️ 本脚本**只读**原始帧，所有产物只写 `--out` 指定的目录。测试请把证据留在
专门的输出目录（建议 `train/opencv-level1/lane_test/<素材名>/`），不要往帧目录里写。

默认参数 = 昨天帧实测标定（2026-10-12 探针 + 全量调参，3 组帧 3984 张全跑）
--------------------------------------------------------------------------
- 昨天帧（`train/opencv-level1/video/frames/`）两线**同时**可见只有 y≈90~230
  （消失点 y≈100~130），y>300 无结构化线；参考自带的底部 ROI（demo y300~480 /
  oldCode 0.50~0.85）在这批帧上双侧只有 **1%~4%** —— 这就是"下摄太平"的直接代价。
- 全量调参结论（双侧率 / 中心离群帧 / 逐帧 |Δcenter| p90）：
    ROI 0.30~0.55 + |k|≥0.20：1098/1100、754/862、2019/2022；离群 24/11/9；p90 11.2
    ROI 0.25~0.50 + |k|≥0.15：**1100/1100、860/862、2017/2022**；离群 **2/4/4**；p90 **10.8/9.8/9.8**
  故默认取 **ROI (0.25, 0.50)（y120~240）+ 斜率闸门 |k| ≥ 0.15**；
  10_11 这个硬素材（右线常被路肩/阴影吞掉）从 86% 拉到 99.8%。
- **固定 Canny(60,140) 优于自适应**（自适应在纹理密集 ROI 里顶到 180/380，反而丢
  弱线：10_11 31/60 → 23/60）→ 默认关自适应，`--canny-adaptive` 可开；
- Hough 其余参数、扫描带=ROI：试过 gap 10 / minLen 25 / 扫描带收窄，都**没有改善**
  （基线已经 99%+），故保持参考原值；
- 口径提醒：ROI 越高（越靠消失点）基线越窄（本档车道宽中位 ~300px，0.30~0.55 档
  ~440px），配对是否跟错线要靠叠加图目检——所以产物里同时给了叠加图与接触表。
- target_x 默认 320（画面中心）。实测 center_x 中位 343~415（本车安装偏右），
  **必须等新素材/上车标定**；脚本会把 center 中位打印出来供定标。

⚠️【重要】这批帧的下摄角度是坏的（太平）。**摄像头压低后的新视频必须重标 ROI**：
先跑 `--roi-sweep`，别把这里的默认值带到新素材上。

用法
----
    cd dev && export PYTHONPATH=.
    PY="E:/venvs/smartcar-ultra/Scripts/python.exe"

    # 跑一组帧：统计 + 每 20 帧一张叠加图 + 每 10 帧一个接触表缩略图 + 离群帧单独存
    "$PY" vision/lane_official.py --frames ../train/opencv-level1/video/frames/sub \
        --out ../train/opencv-level1/lane_test/sub \
        --every 20 --montage 10 --csv --flag-outliers

    # 换素材/换镜头后第一件事：重标 ROI
    "$PY" vision/lane_official.py --frames <DIR> --roi-sweep

    # 还原参考实现原值对照（demo / oldcode）
    "$PY" vision/lane_official.py --frames <DIR> --profile oldcode

    # 单帧细看（打印每条线段的 k 与 x）
    "$PY" vision/lane_official.py --frames <DIR> --start 600 --limit 1 --print-lines
"""
from __future__ import annotations

import argparse
import glob
import math
import os
import shutil
import sys
import tempfile
from dataclasses import dataclass, replace
from typing import Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

# ---------------------------------------------------------------- 参考实现常量
CANNY_LOW0, CANNY_HIGH0 = 60, 140            # 两份参考一致（oldCode config.cpp MIN_YU/MAX_YU）
CANNY_EDGE_LO, CANNY_EDGE_HI = 2000, 2500    # 自适应目标边缘像素数区间
CANNY_STEP_LOW, CANNY_STEP_HIGH = 2, 4       # 自适应步长（边缘太多↑、太少↓）
CANNY_LOW_MIN, CANNY_LOW_MAX = 20.0, 200.0   # 钳位（demo 有；不钳位会跑飞）
CANNY_HIGH_MIN, CANNY_HIGH_MAX = 50.0, 255.0
HOUGH_RHO, HOUGH_THETA_RAD = 1.0, 0.05       # 参考原值（theta 是弧度，≈2.87°）
HOUGH_THRESH, HOUGH_MIN_LEN, HOUGH_MAX_GAP = 50, 30, 5
SLOPE_ABS_MIN, SLOPE_ABS_MAX = 0.15, 2.0     # 参考写 0.25~2.0；放到 0.15 的理由见 docstring
DEMO_MIN_LINE_COUNT = 8                      # demo 的"线太少判停"闸门（默认关，--min-lines 8 开）

PROBE_ROI = (0.25, 0.50)                     # 昨天帧实测定标（docstring 有全量调参表）

# --profile 一键还原两份参考的原始数值（其余参数仍可命令行覆盖）
PROFILES: Dict[str, Dict[str, object]] = {
    # 2026 demo：底部 ROI，扫描 ROI 内 0~99 行（= 整帧 y300~399），线数 <8 判停
    "demo": dict(roi_top=300 / 480.0, roi_bottom=1.0,
                 scan_top=300 / 480.0, scan_bottom=399 / 480.0,
                 min_lines=DEMO_MIN_LINE_COUNT, target_x=320.0,
                 slope_min=0.25, canny_adaptive=True),
    # 2025 oldCode：ROI 0.50~0.85，扫描行 130~230（按 240 行帧归一）
    "oldcode": dict(roi_top=0.50, roi_bottom=0.85,
                    scan_top=130 / 240.0, scan_bottom=230 / 240.0,
                    min_lines=0, target_x=320.0,
                    slope_min=0.25, canny_adaptive=True),
}


# ---------------------------------------------------------------- 参数与读数
@dataclass
class LaneParams:
    """检测参数（全部可命令行覆盖；默认值 = 昨天帧标定，见 docstring）。"""
    roi_top: float = PROBE_ROI[0]        # 找线的行范围（比例，作用于整帧高度）
    roi_bottom: float = PROBE_ROI[1]
    scan_top: Optional[float] = None     # 算中心的扫描行带；None = 与 ROI 同带
    scan_bottom: Optional[float] = None
    canny_low: float = float(CANNY_LOW0)
    canny_high: float = float(CANNY_HIGH0)
    canny_adaptive: bool = False         # 参考是自适应；本批帧实测固定值更好（docstring）
    canny_edge_lo: int = CANNY_EDGE_LO
    canny_edge_hi: int = CANNY_EDGE_HI
    hough_theta_deg: float = math.degrees(HOUGH_THETA_RAD)   # 参考写 0.05rad
    hough_thresh: int = HOUGH_THRESH
    hough_min_len: int = HOUGH_MIN_LEN
    hough_max_gap: int = HOUGH_MAX_GAP
    slope_min: float = SLOPE_ABS_MIN
    slope_max: float = SLOPE_ABS_MAX
    single_mode: str = "border"          # border（参考原样：代画面边界）| off（不给中心）
    min_lines: int = 0                   # >0：两侧线段合计 < min_lines 判 lost（demo=8）
    target_x: float = 320.0              # 期望中心（像素；本车安装偏右，需现场标定）


@dataclass
class Segment:
    """一条通过斜率闸门的线段（k、b 用整帧坐标：x = (y − b) / k）。"""
    k: float
    b: float
    length: float
    p1: Tuple[float, float]
    p2: Tuple[float, float]


@dataclass
class LaneResult:
    """一帧的扫线读数（像素单位；center_x=None = 本帧没有可用中心）。"""
    left_x: Optional[float] = None       # 扫描带中点行上的左线 x
    right_x: Optional[float] = None
    center_x: Optional[float] = None
    error: Optional[float] = None        # center_x − target_x
    n_left: int = 0                      # ROI 内过闸门的左侧线段数
    n_right: int = 0
    both_sides: bool = False             # 中心是否由"两侧都真看到"算出
    lost: bool = False                   # 两侧都没线（或 min_lines 判停）
    single_fill: str = ""                # 单侧兜底走的哪条："border" / "off"
    left_kb: Optional[Tuple[float, float]] = None
    right_kb: Optional[Tuple[float, float]] = None
    crossed_rows: int = 0                # 扫描带内两线交叉、被跳过的行数
    note: str = ""

    @property
    def valid(self) -> bool:
        return self.center_x is not None


# ---------------------------------------------------------------- 坐标工具
def _x_at(k: float, b: float, y: float) -> float:
    """直线 x = (y − b) / k 在行 y 处的 x。"""
    return (y - b) / k


def roi_bounds(h: int, p: LaneParams) -> Tuple[int, int]:
    y0 = int(round(h * float(p.roi_top)))
    y1 = int(round(h * float(p.roi_bottom)))
    y0 = max(0, min(h - 2, y0))
    y1 = max(y0 + 2, min(h, y1))
    return y0, y1


def scan_bounds(h: int, p: LaneParams) -> Tuple[int, int]:
    top = p.roi_top if p.scan_top is None else p.scan_top
    bot = p.roi_bottom if p.scan_bottom is None else p.scan_bottom
    ya = int(round(h * float(top)))
    yb = int(round(h * float(bot)))
    ya = max(0, min(h - 1, ya))
    yb = max(ya + 1, min(h, yb))
    return ya, yb


# ---------------------------------------------------------------- 检测器
class LaneDetector:
    """按参考实现链路扫线（纯 CV，不依赖模型，不碰硬件）。"""

    def __init__(self, params: Optional[LaneParams] = None) -> None:
        self.p = params if params is not None else LaneParams()
        self.canny_low = float(self.p.canny_low)
        self.canny_high = float(self.p.canny_high)

    def reset(self) -> None:
        """换素材/重新起步时清状态（自适应 Canny 的当前值）。"""
        self.canny_low = float(self.p.canny_low)
        self.canny_high = float(self.p.canny_high)

    # -------------------------------------------------- 链路第 1 步：边缘
    def _canny(self, gray_roi: np.ndarray) -> np.ndarray:
        blur = cv2.GaussianBlur(gray_roi, (5, 5), 0.5)
        edges = cv2.Canny(blur, int(round(self.canny_low)), int(round(self.canny_high)), 3)
        if not self.p.canny_adaptive:
            return edges
        # 参考行为：本帧用当前阈值，按边缘数量调一步给**下一帧**（oldCode 同）
        n = int(np.count_nonzero(edges))
        if n > self.p.canny_edge_hi:
            self.canny_low += CANNY_STEP_LOW
            self.canny_high += CANNY_STEP_HIGH
        elif n < self.p.canny_edge_lo:
            self.canny_low -= CANNY_STEP_LOW
            self.canny_high -= CANNY_STEP_HIGH
        self.canny_low = max(CANNY_LOW_MIN, min(CANNY_LOW_MAX, self.canny_low))
        self.canny_high = max(CANNY_HIGH_MIN, min(CANNY_HIGH_MAX, self.canny_high))
        return edges

    # -------------------------------------------------- 链路第 2 步：线段
    def _segments(self, edges: np.ndarray, y0: int) -> List[Segment]:
        lines = cv2.HoughLinesP(edges, HOUGH_RHO, math.radians(self.p.hough_theta_deg),
                                threshold=int(self.p.hough_thresh),
                                minLineLength=int(self.p.hough_min_len),
                                maxLineGap=int(self.p.hough_max_gap))
        out: List[Segment] = []
        if lines is None:
            return out
        for x1, y1, x2, y2 in np.asarray(lines).reshape(-1, 4):
            dx, dy = float(x2 - x1), float(y2 - y1)
            if abs(dx) < 1e-6:                      # 竖直噪声：参考同款直接丢
                continue
            k = dy / dx
            if not (self.p.slope_min <= abs(k) <= self.p.slope_max):
                continue
            b = float(y1 + y0) - k * float(x1)      # 换算到整帧坐标
            out.append(Segment(k=k, b=b, length=math.hypot(dx, dy),
                               p1=(float(x1), float(y1 + y0)), p2=(float(x2), float(y2 + y0))))
        return out

    # -------------------------------------------------- 链路第 3 步：每侧选一条
    def _pick(self, segs: Sequence[Segment], side: str) -> Tuple[Optional[Segment], int]:
        """参考实现：按 k 符号分左右，每侧取 |k| 最大的一条。返回 (代表线, 本侧线段数)。"""
        same = [s for s in segs if (s.k > 0) == (side == "right")]
        if not same:
            return None, 0
        return max(same, key=lambda s: abs(s.k)), len(same)

    # -------------------------------------------------- 对外：一帧读数
    def detect_ex(self, frame_bgr: np.ndarray) -> Tuple[LaneResult, Dict[str, object]]:
        """detect + 中间产物（edges/segs/roi/scan），供 --save-mask 与 --print-lines 用。"""
        h, w = frame_bgr.shape[:2]
        y0, y1 = roi_bounds(h, self.p)
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        edges = self._canny(gray[y0:y1, :])
        segs = self._segments(edges, y0)
        ya, yb = scan_bounds(h, self.p)
        y_ref = (ya + yb) * 0.5

        left, n_l = self._pick(segs, "left")
        right, n_r = self._pick(segs, "right")
        r = LaneResult(n_left=n_l, n_right=n_r)
        if left is not None:
            r.left_kb = (left.k, left.b)
            r.left_x = _x_at(left.k, left.b, y_ref)
        if right is not None:
            r.right_kb = (right.k, right.b)
            r.right_x = _x_at(right.k, right.b, y_ref)

        extras: Dict[str, object] = {"edges": edges, "segs": segs, "roi": (y0, y1),
                                     "scan": (ya, yb), "y_ref": y_ref, "w": w, "h": h}

        if left is None and right is None:
            r.lost = True
            r.note = "两侧都没线"
            return r, extras
        if self.p.min_lines > 0 and (n_l + n_r) < self.p.min_lines:
            r.lost = True
            r.note = f"线段数 {n_l + n_r} < min_lines={self.p.min_lines}（demo 判停口径）"
            return r, extras

        if left is not None and right is not None:
            mids: List[float] = []
            for y in range(ya, yb):
                xl = _x_at(left.k, left.b, y)
                xr = _x_at(right.k, right.b, y)
                if xl >= xr:                 # 两线交叉：跳过该行（偏离 3，见 docstring）
                    r.crossed_rows += 1
                    continue
                mids.append((xl + xr) * 0.5)
            if mids:
                r.center_x = float(np.mean(mids))
            else:
                r.center_x = (float(r.left_x) + float(r.right_x)) * 0.5
                r.note = "扫描带内两线全交叉（退回中点行读数）"
            r.both_sides = True
            r.error = r.center_x - float(self.p.target_x)
            return r, extras

        # ---- 单侧：参考实现原样 —— 缺的一侧代画面边界 ----
        if self.p.single_mode == "off":
            r.single_fill = "off"
            r.note = "只看到一侧（single_mode=off，不给中心）"
            return r, extras
        border = 0.0 if left is None else float(w - 1)
        r.single_fill = "border"
        r.center_x = ((float(r.left_x) if left is not None else float(r.right_x)) + border) * 0.5
        r.error = r.center_x - float(self.p.target_x)
        r.note = f"单侧兜底（{'左' if left is not None else '右'}线 + 画面边界 {border:.0f}）"
        return r, extras

    def detect(self, frame_bgr: np.ndarray) -> LaneResult:
        return self.detect_ex(frame_bgr)[0]


# ---------------------------------------------------------------- 统计
def summarize(rows: Sequence[LaneResult]) -> Dict[str, object]:
    """一组读数的汇总（调参看的就是这张表）。"""
    n = len(rows)
    both = sum(1 for r in rows if r.both_sides)
    single = sum(1 for r in rows if r.center_x is not None and not r.both_sides)
    lost = sum(1 for r in rows if r.center_x is None)
    runs: List[Tuple[int, int]] = []
    s: Optional[int] = None
    for i, r in enumerate(rows):
        bad = r.center_x is None
        if bad and s is None:
            s = i
        if not bad and s is not None:
            runs.append((s, i - 1))
            s = None
    if s is not None:
        runs.append((s, n - 1))
    centers = np.asarray([r.center_x for r in rows if r.center_x is not None], dtype=float)
    errs = np.asarray([r.error for r in rows if r.error is not None], dtype=float)
    nl = np.asarray([r.n_left for r in rows], dtype=float)
    nr = np.asarray([r.n_right for r in rows], dtype=float)

    def pct(a: np.ndarray, q: float) -> float:
        return float(np.percentile(a, q)) if a.size else float("nan")

    return {
        "n": n, "both": both, "single": single, "lost": lost,
        "max_run": max((b - a + 1 for a, b in runs), default=0),
        "runs": runs[:5],
        "c_med": pct(centers, 50) if centers.size else float("nan"),
        "c_p05": pct(centers, 5), "c_p95": pct(centers, 95),
        "e_med": pct(errs, 50), "e_p05": pct(errs, 5), "e_p95": pct(errs, 95),
        "nl_med": pct(nl, 50), "nr_med": pct(nr, 50),
        "min_lines_hits": sum(1 for r in rows if "min_lines" in r.note),
        "crossed_frames": sum(1 for r in rows if r.crossed_rows > 0),
    }


def format_stats(tag: str, st: Dict[str, object]) -> List[str]:
    n = int(st["n"])
    if not n:
        return [f"[LANE] {tag}: 没有帧"]
    lost = int(st["lost"])
    lines = [
        f"[LANE] {tag}: {n} 帧 | 双侧 {st['both']}（{int(st['both']) / n * 100:.0f}%）"
        f" | 单侧 {st['single']} | 丢失 {lost}（{lost / n * 100:.0f}%）"
        f" | 最长连丢 {st['max_run']} 帧",
        f"[LANE]   center_x 中位 {st['c_med']:+.1f}  p05~p95 {st['c_p05']:+.0f}~{st['c_p95']:+.0f}"
        f" | error 中位 {st['e_med']:+.1f}  p05~p95 {st['e_p05']:+.0f}~{st['e_p95']:+.0f}"
        f" | 线段数中位 左 {st['nl_med']:.0f}/右 {st['nr_med']:.0f}",
    ]
    tail = []
    if st["min_lines_hits"]:
        tail.append(f"min_lines 判停 {st['min_lines_hits']} 帧")
    if st["crossed_frames"]:
        tail.append(f"两线交叉 {st['crossed_frames']} 帧")
    if st["runs"]:
        tail.append("前三连丢段 " + " ".join(f"f{a}~{b}({b - a + 1})" for a, b in st["runs"][:3]))
    if tail:
        lines.append("[LANE]   " + "；".join(tail))
    return lines


def evenly_sample(items: Sequence, k: int) -> List:
    """在 items 上均匀取 k 个（不重复；k<=0 或不够时全取）。"""
    if k <= 0 or len(items) <= k:
        return list(items)
    step = len(items) / float(k)
    return [items[min(len(items) - 1, int(i * step))] for i in range(k)]


# ---------------------------------------------------------------- 输入
def list_frames(directory: str) -> List[str]:
    for pat in ("frame_*.jpg", "frame_*.png", "*.jpg", "*.png"):
        found = sorted(glob.glob(os.path.join(directory, pat)))
        if found:
            return found
    return []


def imread_any(path: str) -> Optional[np.ndarray]:
    img = cv2.imread(path)
    if img is None:                       # 中文路径兜底（cv2.imread 在中文路径下返回 None）
        try:
            img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        except Exception:
            img = None
    return img


def open_video(path: str):
    """打开视频；中文文件名自动复制成 ASCII 临时名兜底。返回 (cap, 临时文件路径或 None)。"""
    cap = cv2.VideoCapture(path)
    if cap.isOpened():
        return cap, None
    cap.release()
    tmp = os.path.join(tempfile.gettempdir(),
                       "lane_official_vid" + os.path.splitext(path)[1])
    shutil.copyfile(path, tmp)
    cap = cv2.VideoCapture(tmp)
    if not cap.isOpened():
        cap.release()
        raise SystemExit(f"[LANE] 打不开视频：{path}")
    return cap, tmp


def frame_source(args) -> Tuple[str, List[Tuple[int, np.ndarray]]]:
    """把 --frames/--video 读成一个 [(帧号, 图)] 列表（已经过 start/end/stride/limit 过滤）。"""
    if args.frames:
        paths = list_frames(args.frames)
        if not paths:
            raise SystemExit(f"[LANE] 目录里没有帧图（frame_*.jpg/png）：{args.frames}")
        idx = _pick_indices(len(paths), args)
        out = []
        for i in idx:
            img = imread_any(paths[i])
            if img is None:
                print(f"[LANE] ⚠️ 读不到 {paths[i]}（跳过）")
                continue
            out.append((i, img))
        return os.path.basename(os.path.normpath(args.frames)), out
    if args.video:
        cap, tmp = open_video(args.video)
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
        idx = set(_pick_indices(total if total > 0 else 10 ** 9, args))
        out = []
        i = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if i in idx:
                out.append((i, frame))
            i += 1
        cap.release()
        if tmp:
            os.remove(tmp)
        return os.path.basename(args.video), out
    raise SystemExit("[LANE] 要给 --frames 目录或 --video 文件（--help 看用法）")


def _pick_indices(n: int, args) -> List[int]:
    idx = list(range(n))
    if args.start:
        idx = [i for i in idx if i >= args.start]
    if args.end >= 0:
        idx = [i for i in idx if i <= args.end]
    if args.stride > 1:
        idx = idx[::args.stride]
    if args.limit:
        idx = idx[:args.limit]
    return idx


# ---------------------------------------------------------------- 可视化
def annotate(frame: np.ndarray, r: LaneResult, p: LaneParams, extra: str = "") -> np.ndarray:
    """叠加图：ROI 框、扫描行带、左右线、中心点、目标线、读数文字。"""
    vis = frame.copy()
    h, w = vis.shape[:2]
    y0, y1 = roi_bounds(h, p)
    ya, yb = scan_bounds(h, p)
    cv2.rectangle(vis, (0, y0), (w - 1, y1), (200, 120, 0), 1)
    cv2.line(vis, (0, ya), (w - 1, ya), (0, 200, 200), 1)
    cv2.line(vis, (0, yb), (w - 1, yb), (0, 200, 200), 1)
    for kb, color in ((r.left_kb, (255, 80, 80)), (r.right_kb, (80, 80, 255))):
        if kb is None:
            continue
        xa = int(_x_at(kb[0], kb[1], ya))
        xb = int(_x_at(kb[0], kb[1], yb))
        cv2.line(vis, (xa, ya), (xb, yb), color, 2)
    y_mid = int((ya + yb) * 0.5)
    cv2.line(vis, (int(p.target_x), 0), (int(p.target_x), h), (0, 200, 0), 1)
    if r.center_x is not None:
        cv2.circle(vis, (int(r.center_x), y_mid), 6, (0, 255, 255), 2)
    kind = "both" if r.both_sides else ("lost" if r.lost else ("single:" + r.single_fill))
    err = f"{r.error:+.0f}" if r.error is not None else "None"
    txt = f"{kind} L={r.n_left} R={r.n_right} err={err} {r.note}{extra}"
    cv2.putText(vis, txt, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 0), 3, cv2.LINE_AA)
    cv2.putText(vis, txt, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (60, 255, 60), 1, cv2.LINE_AA)
    return vis


def mask_image(frame: np.ndarray, extras: Dict[str, object], p: LaneParams) -> np.ndarray:
    """中间图：ROI 内 Canny（放大回整帧）+ 过闸门线段 + 闸门外的线（灰）。"""
    h, w = frame.shape[:2]
    y0, y1 = extras["roi"]                          # type: ignore[misc]
    edges = extras["edges"]                         # type: ignore[misc]
    vis = np.zeros((h, w, 3), dtype=np.uint8)
    vis[y0:y1, :] = cv2.cvtColor(cv2.resize(edges, (w, y1 - y0), interpolation=cv2.INTER_NEAREST),
                                 cv2.COLOR_GRAY2BGR)
    for seg in extras["segs"]:                      # type: ignore[misc]
        cv2.line(vis, (int(seg.p1[0]), int(seg.p1[1])), (int(seg.p2[0]), int(seg.p2[1])),
                 (0, 200, 0), 1)
    ya, yb = scan_bounds(h, p)
    cv2.line(vis, (0, ya), (w - 1, ya), (0, 90, 90), 1)
    cv2.line(vis, (0, yb), (w - 1, yb), (0, 90, 90), 1)
    return vis


MONTAGE_COLS, MONTAGE_ROWS = 5, 4                # 接触表：5×4 缩略图
MONTAGE_W, MONTAGE_H = 320, 240


def montage_sheet(thumbs: Sequence[np.ndarray]) -> np.ndarray:
    """把缩略图拼成一张接触表（一眼扫一段视频，比逐张点开快）。"""
    sheet = np.zeros((MONTAGE_ROWS * MONTAGE_H, MONTAGE_COLS * MONTAGE_W, 3), dtype=np.uint8)
    for i, t in enumerate(thumbs[:MONTAGE_COLS * MONTAGE_ROWS]):
        r, c = divmod(i, MONTAGE_COLS)
        sheet[r * MONTAGE_H:(r + 1) * MONTAGE_H, c * MONTAGE_W:(c + 1) * MONTAGE_W] = t
    return sheet


WIDTH_SANE_PX = (80.0, 700.0)                    # 配对宽度的"物理可信"区间（只用于标记，不拒答）
CENTER_JUMP_PX = 100.0                           # 相邻帧中心跳变阈值（只用于标记）


def frame_flag(r: LaneResult, band_rows: int = 0, prev_center: Optional[float] = None) -> str:
    """给"值得人看一眼"的帧打标记（只影响存图，不影响读数）。

    本批帧实测：两线交叉永远发生在扫描带**最顶几行**（那里紧贴消失点，两线本来就快
    重合），属于正常几何，所以只有"交叉吃掉半条带子"才算异常。
    """
    if r.both_sides:
        w = float(r.right_x) - float(r.left_x)
        if not (WIDTH_SANE_PX[0] <= w <= WIDTH_SANE_PX[1]):
            return f"宽度越界({w:.0f})"
        if band_rows and r.crossed_rows > band_rows * 0.5:
            return f"带内深交叉({r.crossed_rows}/{band_rows})"
        if prev_center is not None and r.center_x is not None \
                and abs(r.center_x - prev_center) > CENTER_JUMP_PX:
            return f"中心跳变({r.center_x - prev_center:+.0f})"
    elif r.single_fill == "border":
        return "单侧代边界"
    return ""


# ---------------------------------------------------------------- ROI 扫描（调参）
DEFAULT_SWEEP_ROIS: Tuple[Tuple[float, float], ...] = (
    (0.15, 0.40), (0.20, 0.45), (0.25, 0.50), (0.30, 0.55), (0.35, 0.60),
    (0.40, 0.65), (0.45, 0.75), (0.50, 0.85), (0.62, 0.95), (0.55, 0.95),
)


def parse_sweep_rois(text: str) -> List[Tuple[float, float]]:
    if not text:
        return list(DEFAULT_SWEEP_ROIS)
    out = []
    for chunk in text.split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        top, bottom = chunk.split(",")
        out.append((float(top), float(bottom)))
    return out


def roi_sweep(frames: Sequence[np.ndarray], base: LaneParams,
              candidates: Sequence[Tuple[float, float]], max_frames: int = 60) -> List[dict]:
    """逐档 ROI 打分：换素材/换镜头后第一件事（打分口径 = 双侧率 → 最少丢失）。"""
    use = evenly_sample(frames, max_frames)
    rows = []
    for top, bottom in candidates:
        p = replace(base, roi_top=top, roi_bottom=bottom, scan_top=None, scan_bottom=None)
        det = LaneDetector(p)
        results = [det.detect(f) for f in use]
        st = summarize(results)
        st["roi_top"], st["roi_bottom"] = top, bottom
        rows.append(st)
    rows.sort(key=lambda s: (-int(s["both"]), int(s["lost"])))
    return rows


def print_sweep_table(rows: Sequence[dict], n_frames: int) -> None:
    print(f"[LANE] ROI 扫描（{n_frames} 帧/档；按 双侧率 → 丢失少 排序）：")
    print("[LANE]   ROI上  ROI下   y范围         双侧          单侧   丢失   最长连丢"
          "   center中位(p05~p95)")
    for st in rows:
        h = 480   # 表格只用于阅读；y 范围按 480 行折算（本批素材即 480 行）
        y0 = int(h * float(st["roi_top"]))
        y1 = int(h * float(st["roi_bottom"]))
        c_med = st["c_med"]
        c_txt = f"{c_med:+.0f}({st['c_p05']:+.0f}~{st['c_p95']:+.0f})" \
            if c_med == c_med else "—"          # NaN 判断
        print(f"[LANE]   {st['roi_top']:.2f}   {st['roi_bottom']:.2f}   "
              f"{y0:>3}~{y1:<3}     {st['both']:>3}/{n_frames}"
              f"（{int(st['both']) / max(1, n_frames) * 100:>3.0f}%） {st['single']:>5}"
              f" {st['lost']:>5}   {st['max_run']:>6}     {c_txt}")


# ---------------------------------------------------------------- 命令行
def build_params(args) -> LaneParams:
    p = LaneParams()
    if args.profile:
        for key, value in PROFILES[args.profile].items():
            setattr(p, key, value)
    overrides = {
        "roi_top": args.roi_top, "roi_bottom": args.roi_bottom,
        "scan_top": args.scan_top, "scan_bottom": args.scan_bottom,
        "canny_low": args.canny_low, "canny_high": args.canny_high,
        "hough_theta_deg": args.hough_theta_deg, "hough_thresh": args.hough_thresh,
        "hough_min_len": args.hough_min_len, "hough_max_gap": args.hough_max_gap,
        "slope_min": args.slope_min, "slope_max": args.slope_max,
        "single_mode": args.single, "min_lines": args.min_lines, "target_x": args.target_x,
    }
    for key, value in overrides.items():
        if value is not None:
            setattr(p, key, value)
    if args.canny_adaptive:
        p.canny_adaptive = True
    if args.no_canny_adaptive:
        p.canny_adaptive = False
    return p


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="照 2026 官方 demo + oldCode 的循迹扫线（离线：帧/视频 → 统计 + 叠加图）",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    src = ap.add_argument_group("输入")
    src.add_argument("--frames", default="", help="帧目录（按 frame_*.jpg/png 排序读）")
    src.add_argument("--video", default="", help="视频文件（中文名自动兜底）")
    src.add_argument("--start", type=int, default=0, help="从第几帧开始")
    src.add_argument("--end", type=int, default=-1, help="到第几帧为止（含；-1=到底）")
    src.add_argument("--stride", type=int, default=1, help="隔几帧取一帧")
    src.add_argument("--limit", type=int, default=0, help="最多处理多少帧（0=不限）")
    src.add_argument("--profile", choices=sorted(PROFILES), default="",
                     help="先载入参考实现原值（demo/oldcode），其余参数仍可覆盖")

    det = ap.add_argument_group("检测参数（不填 = 昨天帧标定值，见模块 docstring）")
    det.add_argument("--roi-top", type=float, default=None, help="找线的 ROI 上沿（比例）")
    det.add_argument("--roi-bottom", type=float, default=None, help="找线的 ROI 下沿（比例）")
    det.add_argument("--scan-top", type=float, default=None, help="算中心扫描带上沿（默认同 ROI）")
    det.add_argument("--scan-bottom", type=float, default=None, help="算中心扫描带下沿")
    det.add_argument("--canny-low", type=float, default=None, help="Canny 低阈值")
    det.add_argument("--canny-high", type=float, default=None, help="Canny 高阈值")
    det.add_argument("--canny-adaptive", action="store_true", help="开参考的自适应 Canny")
    det.add_argument("--no-canny-adaptive", action="store_true", help="关自适应（默认即关）")
    det.add_argument("--hough-theta-deg", type=float, default=None, help="Hough 角分辨率（度）")
    det.add_argument("--hough-thresh", type=int, default=None, help="Hough 票数阈值")
    det.add_argument("--hough-min-len", type=int, default=None, help="Hough 最短线段")
    det.add_argument("--hough-max-gap", type=int, default=None, help="Hough 最大间隙")
    det.add_argument("--slope-min", type=float, default=None, help="斜率闸门下限 |k|")
    det.add_argument("--slope-max", type=float, default=None, help="斜率闸门上限 |k|")
    det.add_argument("--single", choices=("border", "off"), default=None,
                     help="单侧兜底：border=参考原样（代画面边界）/ off=不给中心")
    det.add_argument("--min-lines", type=int, default=None, help="两侧线段合计低于此判 lost（demo=8）")
    det.add_argument("--target-x", type=float, default=None, help="期望中心 x（像素）")

    out = ap.add_argument_group("输出")
    out.add_argument("--out", default="", help="输出目录（stats.txt/CSV/叠加图都写这里；测试请单独建目录）")
    out.add_argument("--every", type=int, default=0, help="每 N 帧存一张叠加图（0=不存）")
    out.add_argument("--montage", type=int, default=0, help="每 N 帧收进接触表缩略图（0=不存）")
    out.add_argument("--flag-outliers", action="store_true",
                     help="宽度越界/两线交叉/单侧代边界 的帧单独存图并在结尾列出")
    out.add_argument("--save-mask", action="store_true", help="连同 Canny/线段中间图一起存")
    out.add_argument("--csv", action="store_true", help="逐帧读数写 out/frames.csv")
    out.add_argument("--print-lines", action="store_true", help="逐帧打印每条线段 (k, x@扫描带)")
    out.add_argument("--quiet", action="store_true", help="不打印逐帧摘要")

    sw = ap.add_argument_group("调参")
    sw.add_argument("--roi-sweep", action="store_true", help="扫候选 ROI 出打分表再退出")
    sw.add_argument("--sweep-rois", default="", help='候选 "上,下;上,下;…"（默认内置一组）')
    sw.add_argument("--sweep-frames", type=int, default=60, help="ROI 扫描每档用多少帧")
    return ap


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    params = build_params(args)
    if not args.frames and not args.video:
        build_parser().print_help()
        return 2
    tag, items = frame_source(args)
    if not items:
        print("[LANE] 没有可处理的帧")
        return 1
    print(f"[LANE] {tag}: {len(items)} 帧 | ROI {params.roi_top:.2f}~{params.roi_bottom:.2f}"
          f"（y {roi_bounds(items[0][1].shape[0], params)[0]}~"
          f"{roi_bounds(items[0][1].shape[0], params)[1]}）"
          f" | Canny {params.canny_low:.0f}/{params.canny_high:.0f}"
          f"{'自适应' if params.canny_adaptive else '固定'}"
          f" | 斜率 |k| {params.slope_min}~{params.slope_max}"
          f" | target {params.target_x:.0f}"
          f"{' | min_lines ' + str(params.min_lines) if params.min_lines else ''}")

    det = LaneDetector(params)

    if args.roi_sweep:
        cands = parse_sweep_rois(args.sweep_rois)
        sample = evenly_sample([f for _, f in items], args.sweep_frames)
        rows = roi_sweep(sample, params, cands)
        print_sweep_table(rows, len(sample))
        if args.out:
            os.makedirs(args.out, exist_ok=True)
            with open(os.path.join(args.out, "roi_sweep.txt"), "w", encoding="utf-8") as f:
                for st in rows:
                    f.write(f"{st['roi_top']:.2f},{st['roi_bottom']:.2f},"
                            f"{st['both']},{st['single']},{st['lost']},"
                            f"{st['max_run']},{st['c_med']:.1f}\n")
            print(f"[LANE] 扫描表 → {os.path.join(args.out, 'roi_sweep.txt')}")
        return 0

    if args.out:
        os.makedirs(args.out, exist_ok=True)
    csv_lines = ["frame,both,single,lost,left_x,right_x,center_x,error,n_left,n_right,note"]
    results: List[LaneResult] = []
    flags: List[Tuple[int, str]] = []
    thumbs: List[np.ndarray] = []
    sheet_no = 0
    prev_c: Optional[float] = None
    for idx, frame in items:
        r, extras = det.detect_ex(frame)
        results.append(r)
        kind = "both" if r.both_sides else ("lost" if r.lost else "single")
        ya0, yb0 = scan_bounds(frame.shape[0], params)
        flag = frame_flag(r, band_rows=yb0 - ya0, prev_center=prev_c)
        if r.center_x is not None:
            prev_c = float(r.center_x)
        if flag:
            flags.append((idx, flag))
        if not args.quiet:
            err = f"{r.error:+.1f}" if r.error is not None else "None"
            print(f"[LANE] f{idx:06d} {kind:6s} L={r.n_left:>2} R={r.n_right:>2} "
                  f"c={('—' if r.center_x is None else f'{r.center_x:.0f}'):>4} err={err:>7}"
                  f"{'  ' + r.note if r.note else ''}")
        if args.print_lines:
            for side, seg in (("L", r.left_kb), ("R", r.right_kb)):
                if seg is not None:
                    print(f"[LANE]      {side} k={seg[0]:+.3f} "
                          f"x@scan={(extras['scan'][0] + extras['scan'][1]) / 2:.0f}:"
                          f"{_x_at(seg[0], seg[1], (extras['scan'][0] + extras['scan'][1]) / 2):.0f}")
            for s in extras["segs"]:            # type: ignore[misc]
                print(f"[LANE]      seg k={s.k:+.3f} len={s.length:.0f}")
        csv_lines.append(f"{idx},{int(r.both_sides)},{int(r.center_x is not None and not r.both_sides)},"
                         f"{int(r.lost)},{_fmt(r.left_x)},{_fmt(r.right_x)},{_fmt(r.center_x)},"
                         f"{_fmt(r.error)},{r.n_left},{r.n_right},"
                         f"\"{r.note}\"")
        if args.out and (args.every or args.montage or (args.flag_outliers and flag)):
            vis = annotate(frame, r, params)
            if args.every and idx % args.every == 0:
                cv2.imwrite(os.path.join(args.out, f"f_{idx:06d}.jpg"), vis)
                if args.save_mask:
                    cv2.imwrite(os.path.join(args.out, f"mask_{idx:06d}.jpg"),
                                mask_image(frame, extras, params))
            if args.flag_outliers and flag:
                cv2.imwrite(os.path.join(args.out, f"flag_{idx:06d}.jpg"), vis)
            if args.montage and idx % args.montage == 0:
                thumbs.append(cv2.resize(vis, (MONTAGE_W, MONTAGE_H),
                                         interpolation=cv2.INTER_AREA))
                if len(thumbs) == MONTAGE_COLS * MONTAGE_ROWS:
                    cv2.imwrite(os.path.join(args.out, f"sheet_{sheet_no:03d}.jpg"),
                                montage_sheet(thumbs))
                    sheet_no += 1
                    thumbs = []
    if args.out and thumbs:
        cv2.imwrite(os.path.join(args.out, f"sheet_{sheet_no:03d}.jpg"), montage_sheet(thumbs))

    st = summarize(results)
    lines = format_stats(tag, st)
    if flags:
        by_kind: Dict[str, List[int]] = {}
        for i, kind in flags:
            key = kind.split("(")[0]
            by_kind.setdefault(key, []).append(i)
        lines.append("[LANE] 需人看的帧：" + "；".join(
            f"{k} {len(v)} 帧 {v[:8]}{'…' if len(v) > 8 else ''}" for k, v in sorted(by_kind.items())))
    for line in lines:
        print(line)
    if args.out:
        with open(os.path.join(args.out, "stats.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        if args.csv:
            with open(os.path.join(args.out, "frames.csv"), "w", encoding="utf-8") as f:
                f.write("\n".join(csv_lines) + "\n")
        if flags:
            with open(os.path.join(args.out, "flags.txt"), "w", encoding="utf-8") as f:
                for i, kind in flags:
                    f.write(f"{i:06d},{kind}\n")
        print(f"[LANE] 输出 → {os.path.abspath(args.out)}")
    return 0


def _fmt(v: Optional[float]) -> str:
    return "" if v is None else f"{v:.1f}"


if __name__ == "__main__":
    sys.exit(main())
